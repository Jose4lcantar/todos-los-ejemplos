import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, ReactiveFormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ejemplo5';

  //propiedas
  nomClient='';
  emailClient= '';
  mensajeClient='';
  statusClient='';
  municipioClient='';
  autorizacionClient=false;

  enviado=false;

  formContact = new FormGroup({
    nombre: new FormControl('',[
      Validators.required,
      Validators.minLength(10),
    ]),
    email: new FormControl('',[
      Validators.required,
      Validators.email
    ]),
    mensaje: new FormControl('',[
      Validators.required,
      Validators.maxLength(500)
    ]),
    status: new FormControl('',[
      Validators.required
    ]),
    municipio: new FormControl('',[
      Validators.required
    ]),
    autorizacion: new FormControl(false)
  });

  //metodo que se ejecuta cuando se envia el formulario
  onSubmit(){
    this.enviado=true;
    if(this.formContact.valid){
      this.nomClient = this.formContact.value.nombre!;
    this.emailClient = this.formContact.value.email!;
    this.mensajeClient = this.formContact.value.mensaje!;
    this.statusClient = this.formContact.value.status!;
    this.municipioClient = this.formContact.value.municipio!;
    this.autorizacionClient = this.formContact.value.autorizacion!;
    }
  }
}